package org.example.swordsnstuffapi.dto;

public class CategoryDTO {

    public String name;

//    public CategoryDTO(String name) {
//        this.name = name;
//    }
}
